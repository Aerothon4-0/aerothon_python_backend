import React from 'react';

function Error(props) {
    return (
        <div>
            404 Error, Please go back
        </div>
    );
}

export default Error;