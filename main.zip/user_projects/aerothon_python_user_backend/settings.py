


MAIN_BACKEND_SERVER_URL = "http://0.0.0.0:5000/code/get_website_data"
