#!/usr/bin/env bash

#export SQLALCHEMY_DATABASE_URI='mysql+pymysql://client-service-api:uAPmg#89-$@-Nkt%@host.docker.internal/service_partner_integration'

# flask run --host=0.0.0.0 --port=5000
# echo "flask run started"

# flask run --port=5000

# echo "flask run end"
